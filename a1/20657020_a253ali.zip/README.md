# Assignment 1
To run this, go to your terminal and enter the following from the root folder:

```source vent/bin/activate```

```python3 a1/main.py data/raw```

If you experience an error suggesting imports are not valid for stopwords and punks from nltk, uncomment lines 12 and 13 in a1/main.py and rerun.